from mongomini.documents import Document

